// ==========================================
// NAV.JS - DUMMY FILE
// ==========================================
// Diese Datei existiert nur um 404 Fehler zu vermeiden
// Sie wird von einem anderen Script erwartet, macht aber nichts

console.log('nav.js loaded (dummy file)');
